package bnsit.ms.arq;

public interface InputAware {
    void onTextLineEntered(String text);
}
