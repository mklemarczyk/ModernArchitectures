package bnsit.ms.arq.library.borrowing;

public class Money {
    private int value;

    public Money(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
