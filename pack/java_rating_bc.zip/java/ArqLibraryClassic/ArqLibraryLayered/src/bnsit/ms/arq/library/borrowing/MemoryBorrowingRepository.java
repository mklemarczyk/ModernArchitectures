package bnsit.ms.arq.library.borrowing;

import bnsit.ms.arq.library.Generated;

import java.util.ArrayList;
import java.util.List;

public class MemoryBorrowingRepository implements BorrowingRepository {
    private static List<Borrowing> borrowings = new ArrayList<>();

    public void clear() {
        borrowings.clear();
    }

    public void init() {
        // no borrowings at start yet
    }

    @Override
    public void add(Borrowing borrowing) {
        borrowing.setId(Generated.borrowingId());
        borrowings.add(borrowing);
    }

    @Override
    public Borrowing findByBookId(long bookId, long userId) {
        // userId omitted for simplicity
        for (Borrowing borrowing : borrowings)
        {
            if (borrowing.getBookId() == bookId)
            {
                return borrowing;
            }
        }

        return null;
    }
}
