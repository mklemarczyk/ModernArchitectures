package bnsit.ms.arq.library.borrowing;

public class BorrowingFactory {
    public TermsPolicy createTerms(String termsType) {
        if (termsType.equals("long")) {
            return new LongTermBorrowing();
        } else if (termsType.equals("normal")) {
            return new NormalTermBorrowing();
        } else if (termsType.equals("short")) {
            return new ShortTermBorrowing();
        }
        throw new BorrowingException("Borrow terms not recoginzed: " + termsType);
    }

    public Borrowing createBorrowing(long userId, long bookId, String termsType) {
        return new Borrowing(userId, bookId, createTerms(termsType));
    }
}
