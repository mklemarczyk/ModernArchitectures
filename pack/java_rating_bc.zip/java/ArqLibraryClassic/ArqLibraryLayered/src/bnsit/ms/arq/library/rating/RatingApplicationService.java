package bnsit.ms.arq.library.rating;

public class RatingApplicationService {
    private RatingRepository repository;
    private RatingFactory factory;

    public RatingApplicationService(RatingRepository repository, RatingFactory factory) {
        this.repository = repository;
        this.factory = factory;
    }

    public void rate(long bookId, int value, String nickname) {
        Rating rating = repository.findBy(bookId);

        if (rating == null) {
            rating = factory.create(bookId);
            repository.add(rating);
        }

        rating.rate(value, nickname);
        repository.update(rating);
    }

    public double rating(long bookId) {
        Rating rating = repository.findBy(bookId);

        if (rating == null) {
            // book not found, -1 means no rating
            return -1.0;
        }

        return rating.value();
    }
}
