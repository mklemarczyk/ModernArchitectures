package bnsit.ms.arq.library.rating;

public class RatingException extends RuntimeException {
    public RatingException(String message) {
        super(message);
    }
}
