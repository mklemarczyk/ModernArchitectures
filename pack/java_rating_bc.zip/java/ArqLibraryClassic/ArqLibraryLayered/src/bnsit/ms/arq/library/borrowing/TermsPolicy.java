package bnsit.ms.arq.library.borrowing;

import java.util.Date;

public interface TermsPolicy {
    Date returnDate(Date start);
    Money fine(Date start, Date end);
    String type();
}
