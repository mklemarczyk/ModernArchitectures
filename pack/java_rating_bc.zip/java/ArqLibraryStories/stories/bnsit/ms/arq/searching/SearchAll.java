package bnsit.ms.arq.searching;

import bnsit.ms.arq.library.LibraryFixture;
import org.junit.Before;
import org.junit.Test;

public class SearchAll {

    private LibraryFixture fixture = null;

    @Before
    public void setupFixture()
    {
        fixture = new LibraryFixture();
    }

    @Test
    public void shouldSearchAllBooks()
    {
        //given
        fixture.applicationStarted();
        fixture.hasSampleBooks();

        //when
        fixture.userEnters("search");

        //then
        fixture.then();
        fixture.systemShows(LibraryFixture.title("Karolcia"));
        fixture.systemShows(LibraryFixture.author("Maria Kruger"));
        fixture.systemShows(LibraryFixture.title("Renesans"));
        fixture.systemShows(LibraryFixture.author("Jerzy Konieczny"));
        fixture.systemShowsAtLeastLines(fixture.startBooksCount());
    }
}
