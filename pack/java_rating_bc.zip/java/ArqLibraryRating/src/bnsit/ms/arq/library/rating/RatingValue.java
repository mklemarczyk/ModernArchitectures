package bnsit.ms.arq.library.rating;

public class RatingValue {
    private double value;

    public RatingValue(int rating) {
        this.value = rating;
    }

    public double value() {
        return value;
    }
}
