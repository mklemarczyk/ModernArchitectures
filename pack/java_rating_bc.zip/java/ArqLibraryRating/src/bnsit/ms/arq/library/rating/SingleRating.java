package bnsit.ms.arq.library.rating;

import java.util.Date;

public class SingleRating {
    private RatingValue rating;
    private Date when;
    private String nickname;

    public SingleRating(int value, String nickname) {
        this.rating = new RatingValue(value);
        this.nickname = nickname;
        this.when = new Date();
    }

    public double value() {
        return rating.value();
    }
}
