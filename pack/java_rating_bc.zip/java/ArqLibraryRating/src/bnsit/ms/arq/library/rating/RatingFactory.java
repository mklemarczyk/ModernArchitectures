package bnsit.ms.arq.library.rating;

public class RatingFactory {
    public Rating create(long bookId) {
        return new Rating(bookId);
    }
}
