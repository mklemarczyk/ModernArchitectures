package bnsit.ms.arq.library.rating;

import java.util.ArrayList;
import java.util.List;

public class Rating {
    private long bookId;
    private List<SingleRating> singleRatings = new ArrayList<>();

    public Rating(long bookId) {

        this.bookId = bookId;
    }

    public void rate(int value, String nickname) {
        singleRatings.add(new SingleRating(value, nickname));
    }

    public double value() {
        return singleRatings.stream()
                .mapToDouble(r -> r.value())
                .average().getAsDouble();
    }

    public long getBookId() {
        return bookId;
    }
}
