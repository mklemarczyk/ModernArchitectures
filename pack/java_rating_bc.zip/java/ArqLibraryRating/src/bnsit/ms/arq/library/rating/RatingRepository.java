package bnsit.ms.arq.library.rating;

public interface RatingRepository {
    Rating findBy(long bookId);

    void add(Rating rating);

    void update(Rating rating);
}
