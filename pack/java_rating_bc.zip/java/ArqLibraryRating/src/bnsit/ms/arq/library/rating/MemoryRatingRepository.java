package bnsit.ms.arq.library.rating;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MemoryRatingRepository implements RatingRepository {
    private List<Rating> ratings = new ArrayList<>();

    @Override
    public Rating findBy(long bookId) {
        Optional<Rating> optional = ratings.stream().filter(r -> r.getBookId() == bookId).findFirst();
        if (!optional.isPresent()) {
            return null;
        }

        return optional.get();
    }

    @Override
    public void add(Rating rating) {
        ratings.add(rating);
    }

    @Override
    public void update(Rating rating) {
        // in memory, nothing happens
    }

    public void init() {
        Rating rating1 = new Rating(1);
        rating1.rate(4, "nowak");
        rating1.rate(2, "koper");
        ratings.add(rating1);

        Rating rating2 = new Rating(2);
        rating2.rate(1, "nowak");
        rating2.rate(5, "kowalski");
        ratings.add(rating2);

        Rating rating3 = new Rating(3);
        rating3.rate(1, "nowak");
        rating3.rate(5, "kowalski");
        ratings.add(rating3);

        Rating rating4 = new Rating(4);
        rating4.rate(2, "koper");
        rating4.rate(2, "kowalski");
        ratings.add(rating4);
    }

    public void clear() {
        ratings.clear();
    }
}
