package bnsit.ms.arq.library.borrowing;

import java.util.Date;

public class Borrowing {
    private long id;
    private long userId;
    private long bookId;
    private Date when;
    private Date returned; // NullDate

    private TermsPolicy terms;

    public Borrowing(long userId, long bookId, TermsPolicy terms) {
        this.userId = userId;
        this.bookId = bookId;
        this.terms = terms;
        this.when = new Date();
        this.returned = null; // user NullObject
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getBookId() {
        return bookId;
    }

    public Date expectedReturn() {
        return terms.returnDate(when);
    }

    public boolean overdue() {
        return terms.returnDate(when).before(new Date());
    }

    public boolean returned() {
        return returned != null;
    }

    public String termsType() {
        return terms.type();
    }

    public String borrowed() {
        if (this.returned()) {
            return "[available]";
        }

        return String.format("[borrowed, %s]", this.termsType());
    }

    public void returnBook() {
        this.returned = new Date();

        // TODO publish BookReturnedEvent
        // publisher.publish(new BookReturnedEvent(bookId, userId, this.returned));

        if (overdue()) {
            // TODO publish BookOverdueOnReturn
            // publisher.publish(new BookOverdueOnReturn(bookId, userId, terms.fine(this.when, this.returned));
        }
    }
}
