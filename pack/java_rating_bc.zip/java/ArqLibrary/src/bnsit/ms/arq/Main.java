package bnsit.ms.arq;

import bnsit.ms.arq.library.*;
import bnsit.ms.arq.library.borrowing.BorrowingFactory;
import bnsit.ms.arq.library.borrowing.BorrowingManager;
import bnsit.ms.arq.library.borrowing.MemoryBorrowingRepository;
import bnsit.ms.arq.library.rating.MemoryRatingRepository;
import bnsit.ms.arq.library.rating.RatingApplicationService;
import bnsit.ms.arq.library.rating.RatingFactory;

public class Main {

    public static void main(String[] args) {
        Application application = new Application(new ConsoleIn(), new ConsoleOut());
        BooksDao booksDao = CreateBooksDao();
        application.setup(new BooksManager(booksDao));
        application.setup(new BorrowingManager(CreateMemoryBorrowingRepository(), new BorrowingFactory()));
        application.setup(createUserDao());
        application.setup(createRatingApplicationService());

        application.start();
    }

    private static RatingApplicationService createRatingApplicationService() {
        MemoryRatingRepository ratingRepository = new MemoryRatingRepository();
        ratingRepository.init();

        return new RatingApplicationService(ratingRepository, new RatingFactory());
    }

    private static UserDao createUserDao() {
        MemoryUserDao userDao = new MemoryUserDao();
        userDao.init();

        return userDao;
    }

    private static MemoryBorrowingRepository CreateMemoryBorrowingRepository()
    {
        MemoryBorrowingRepository repository = new MemoryBorrowingRepository();
        repository.init();

        return repository;
    }

    private static MemoryUserDao CreateMemoryUserDao()
    {
        MemoryUserDao dao = new MemoryUserDao();
        dao.init();
        return dao;
    }

    private static MemoryBooksDao CreateBooksDao()
    {
        MemoryBooksDao dao = new MemoryBooksDao();
        dao.init();

        return dao;
    }
}
