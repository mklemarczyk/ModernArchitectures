package bnsit.ms.arq;

public interface UserIn {
    String readLine();
}
