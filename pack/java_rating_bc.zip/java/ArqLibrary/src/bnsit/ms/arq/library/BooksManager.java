package bnsit.ms.arq.library;

import java.util.Iterator;

public class BooksManager {
    private BooksDao dao;

    public BooksManager(BooksDao dao) {
        this.dao = dao;
    }

    public void create(String title, String author, String isbn, String publisher, int year, String category) {
        dao.insert(new Book(title, author, isbn, publisher, year, category));
    }

    public Iterator<Book> findAll() {
        return dao.findAll();
    }

    public Iterator<Book> findByTitle(String toSearch) {
        return dao.findByTitle(toSearch);
    }

    public Book findById(long bookId) {
        return dao.findById(bookId);
    }

}
