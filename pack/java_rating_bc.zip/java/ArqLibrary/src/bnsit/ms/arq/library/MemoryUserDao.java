package bnsit.ms.arq.library;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MemoryUserDao implements UserDao {
    private static final List<User> users = new ArrayList<User>();

    @Override
    public void insert(User user)
    {
        user.setId(Generated.userId());
        users.add(user);
    }

    @Override
    public User findById(long userId) {
        Optional<User> optional = users.stream().filter(u -> u.getId() == userId).findFirst();
        if (!optional.isPresent()) {
            throw new LibrarianException(String.format("User not found with id = %d", userId));
        }

        return optional.get();
    }

    public void clear() {
        users.clear();
    }

    public void init() {
        insert(new User("kowalski", "kowal", "Jan Kowalski", "Gdynia", "87052507754"));
        insert(new User("nowak", "nowypass", "Piotr Nowak", "Warszawa", "890224031121"));
        insert(new User("koper", "dupadupa", "Wojciech Koperski", "Zakopane", "91121202176"));
    }
}
