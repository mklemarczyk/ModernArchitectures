package bnsit.ms.arq;

public interface UserOut {
    void print(String text);

    void printLine(String text);
}
