package bnsit.ms.arq;

import bnsit.ms.arq.library.BooksDao;
import bnsit.ms.arq.library.BooksManager;
import bnsit.ms.arq.library.MemoryBooksDao;
import bnsit.ms.arq.library.MemoryUserDao;
import bnsit.ms.arq.library.borrowing.BorrowingFactory;
import bnsit.ms.arq.library.borrowing.BorrowingManager;
import bnsit.ms.arq.library.borrowing.MemoryBorrowingRepository;

public class Main {

    public static void main(String[] args) {
        Application application = new Application(new ConsoleIn(), new ConsoleOut());
        BooksDao booksDao = CreateBooksDao();
        application.setup(new BooksManager(booksDao));
        application.setup(new BorrowingManager(CreateMemoryBorrowingRepository(), new BorrowingFactory()));
        application.start();
    }

    private static MemoryBorrowingRepository CreateMemoryBorrowingRepository()
    {
        MemoryBorrowingRepository repository = new MemoryBorrowingRepository();
        repository.init();

        return repository;
    }

    private static MemoryUserDao CreateMemoryUserDao()
    {
        MemoryUserDao dao = new MemoryUserDao();
        dao.init();
        return dao;
    }

    private static MemoryBooksDao CreateBooksDao()
    {
        MemoryBooksDao dao = new MemoryBooksDao();
        dao.init();

        return dao;
    }
}
