package bnsit.ms.arq.library.borrowing;

public class BorrowingException extends RuntimeException {
    public BorrowingException(String message) {
        super(message);
    }
}
