package bnsit.ms.arq.library.borrowing;

public interface BorrowingRepository {
    void add(Borrowing borrowing);

    Borrowing findByBookId(long bookId, long userId);
}
