package bnsit.ms.arq.library.borrowing;

public class BorrowingManager {
    private BorrowingRepository borrowingRepository;
    private BorrowingFactory borrowingFactory;

    public BorrowingManager(BorrowingRepository borrowingRepository, BorrowingFactory borrowingFactory) {
        this.borrowingRepository = borrowingRepository;
        this.borrowingFactory = borrowingFactory;
    }

    public void borrow(long userId, long bookId, String termsType) {
        Borrowing borrowing = borrowingFactory.createBorrowing(userId, bookId, termsType);

        borrowingRepository.add(borrowing);
    }

    public String borrowed(long bookId, long userId) {
        Borrowing borrowing = borrowingRepository.findByBookId(bookId, userId);

        // null object?
        if (borrowing == null) {
            return "[available]";
        }

        return borrowing.borrowed();
    }

    public void returnBook(long bookId, long userId) {
        Borrowing borrowing = borrowingRepository.findByBookId(bookId, userId);

        if (borrowing == null) {
            throw new BorrowingException("Book not borrowed with id = " + bookId);
        }

        borrowing.returnBook();
    }
}
