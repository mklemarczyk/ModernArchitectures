package bnsit.ms.arq.library;

public class LibrarianException extends RuntimeException {
    public LibrarianException(String message) {
        super(message);
    }
}
