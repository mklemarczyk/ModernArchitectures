package bnsit.ms.arq.library.borrowing;

import java.util.Calendar;
import java.util.Date;

public class NormalTermBorrowing implements TermsPolicy {
    @Override
    public Date returnDate(Date start) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(start);
        calendar.add(Calendar.MONTH, 1);

        return calendar.getTime();
    }

    @Override
    public Money fine(Date start, Date end) {
        return new Money(10);
    }

    @Override
    public String type() {
        return "normal term";
    }
}
