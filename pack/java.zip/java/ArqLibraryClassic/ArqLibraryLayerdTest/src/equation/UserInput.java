package equation;

public interface UserInput {
    double nextDouble();
}
