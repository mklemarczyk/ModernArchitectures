package equation;

public interface UserOutput {
    void print(String text);

    void println(String text);
}
